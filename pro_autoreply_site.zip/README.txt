
AutoReply Pro - Ready prototype

Files in this package:
- index.html      -> Polished landing page (Arabic, black/gold)
- dashboard.html  -> Mockup for dashboard view
- server.js       -> Simple Express server to serve pages + APIs
- package.json    -> Node.js dependencies (express, sqlite3)
- data.sqlite     -> SQLite file (initialised)

What this package does:
- Presents a professional landing page and a dashboard mockup.
- Provides a small backend skeleton that can store users and pages.
- Designed to be used with ManyChat initially; store user registrations locally.

How to run (locally):
1. Ensure Node.js installed.
2. npm install
3. npm start
4. Visit http://localhost:3000

Notes on ManyChat integration:
- This skeleton DOES NOT perform messaging. For ManyChat flow integration, direct users to sign in to ManyChat and connect their page.
- Later, when you have Developer access, you can expand server.js to accept webhooks and use the Graph API to manage comments/messages.
